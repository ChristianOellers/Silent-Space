/**
 * Global vars for the project.
 */

// --------------------------------------------------------------------------------------------- Globals vars, Constants

var STOP = false,
    FPS  = 1000 / 60;

